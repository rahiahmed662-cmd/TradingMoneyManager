# Trading Money Manager (Android / Kotlin)

A starter Android app for manual binary-options money-management calculations.

## Default example
- Capital: $500
- Payout: 80%
- First trade: $10
- Desired net profit after recovering one loss: $5
- Planned trades: 5

Recovery formula:
`recovery stake = (previous loss + desired net profit) / payout rate`

For the defaults: `($10 + $5) / 0.80 = $18.75`.
If the $18.75 recovery trade wins at 80% payout, its profit is $15.00; after the earlier $10 loss, net result is +$5.00 (before fees).

## Build an APK
1. Install Android Studio (latest stable) on a computer.
2. Open Android Studio and choose **Open**, then select this `TradingMoneyManager` folder.
3. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35 and the Android Gradle Plugin dependencies.
4. For a test build, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When it finishes, click **locate** in the notification. The APK is usually at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and open it. You may need to allow installing apps from that file manager.

## Notes
- This source project is not itself an APK. The APK is produced by building it in Android Studio.
- Trade tracker estimates P/L using the same stake for each recorded trade; it is a basic tracker, not an exchange connection.
- No signals, broker login, automatic trades, or guaranteed recovery are included.
- The app is a calculation aid, not financial advice. Binary options are high risk; never increase stake simply to chase losses.
