package com.example.tradingmoneymanager

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var capitalInput: EditText
    private lateinit var payoutInput: EditText
    private lateinit var stakeInput: EditText
    private lateinit var targetInput: EditText
    private lateinit var tradeCount: Spinner
    private lateinit var resultBox: LinearLayout
    private lateinit var trackerBox: LinearLayout
    private var outcomes = mutableListOf<Boolean?>()
    private var initialCapital = 500.0

    private val bg = Color.rgb(246, 248, 250)
    private val ink = Color.rgb(25, 39, 52)
    private val green = Color.rgb(24, 115, 82)
    private val red = Color.rgb(184, 53, 53)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        calculate()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("TRADING MONEY MANAGER", 23f, ink, true))
        root.addView(text("পুঁজি, রিকভারি ও ঝুঁকির হিসাব", 15f, Color.DKGRAY, false).apply {
            setPadding(0, dp(4), 0, dp(16))
        })

        val inputs = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(inputs, matchWrap())
        capitalInput = field(inputs, "মোট পুঁজি (USD)", "500")
        payoutInput = field(inputs, "Payout (%)", "80")
        stakeInput = field(inputs, "প্রথম ট্রেডের অঙ্ক (USD)", "10")
        targetInput = field(inputs, "লক্ষ্য নিট লাভ (USD)", "5")

        inputs.addView(text("মোট ট্রেডের সংখ্যা", 14f, ink, true).apply {
            setPadding(0, dp(8), 0, dp(4))
        })
        tradeCount = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("3 ট্রেড", "5 ট্রেড", "10 ট্রেড"))
        tradeCount.adapter = adapter
        tradeCount.setSelection(1)
        inputs.addView(tradeCount, matchWrap())

        val calcButton = Button(this).apply {
            text = "হিসাব করো"
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { calculate() }
        }
        inputs.addView(calcButton, matchWrap())

        root.addView(text("হিসাবের ফলাফল", 19f, ink, true).apply {
            setPadding(0, dp(20), 0, dp(8))
        })
        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(resultBox, matchWrap())

        root.addView(text("ট্রেড ট্র্যাকার", 19f, ink, true).apply {
            setPadding(0, dp(20), 0, dp(8))
        })
        root.addView(text("প্রতিটি ট্রেডে Win বা Loss চাপলে আনুমানিক ব্যালেন্স আপডেট হবে।", 13f, Color.DKGRAY, false))
        trackerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(trackerBox, matchWrap())

        root.addView(text(
            "ঝুঁকি সতর্কতা: রিকভারি ট্রেড জিতবেই এমন নিশ্চয়তা নেই। ধারাবাহিক লস হলে পুঁজি দ্রুত কমতে পারে। এটি কেবল হিসাবের টুল, ট্রেডিং পরামর্শ নয়.",
            12f, Color.DKGRAY, false
        ).apply { setPadding(0, dp(18), 0, 0) })
    }

    private fun field(parent: LinearLayout, label: String, value: String): EditText {
        parent.addView(text(label, 14f, ink, true).apply {
            setPadding(0, dp(8), 0, dp(3))
        })
        val e = EditText(this).apply {
            setSingleLine(true)
            setText(value)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 16f
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(245, 247, 249))
        }
        parent.addView(e, matchWrap())
        return e
    }

    private fun calculate() {
        val capital = capitalInput.text.toString().toDoubleOrNull() ?: 0.0
        val payout = payoutInput.text.toString().toDoubleOrNull() ?: 0.0
        val stake = stakeInput.text.toString().toDoubleOrNull() ?: 0.0
        val target = targetInput.text.toString().toDoubleOrNull() ?: 0.0
        val n = when (tradeCount.selectedItemPosition) { 0 -> 3; 2 -> 10; else -> 5 }
        initialCapital = max(0.0, capital)
        if (outcomes.size != n) {
            outcomes = MutableList(n) { null }
        }

        resultBox.removeAllViews()
        val valid = capital > 0 && payout > 0 && stake > 0 && target >= 0
        if (!valid) {
            resultBox.addView(text("সঠিক ধনাত্মক পুঁজি, payout ও ট্রেডের অঙ্ক দাও।", 14f, red, true))
            renderTracker(capital, payout, stake, n)
            return
        }

        val rate = payout / 100.0
        val recoveryStake = (stake + target) / rate
        val maxLoss = stake * n
        val remaining = capital - maxLoss
        addResult("মোট পুঁজি", money(capital))
        addResult("পেআউট", "${fmt(payout)}%")
        addResult("প্রথম ট্রেড", money(stake))
        addResult("একটি ${money(stake)} লস + ${money(target)} লক্ষ্য লাভ তুলতে প্রয়োজন", money(recoveryStake))
        addResult("পরের ট্রেডে এই অঙ্ক লস হলে মোট ক্ষতি", money(stake + recoveryStake))
        addResult("$nটি ট্রেডই ${money(stake)} করে লস হলে", "ক্ষতি ${money(maxLoss)} · অবশিষ্ট ${money(remaining)}")
        val riskText = if (maxLoss >= capital) "এই উদাহরণে নির্ধারিত ট্রেডগুলো পুঁজির সমান/বেশি ঝুঁকিতে ফেলতে পারে।"
            else "একই অঙ্কের $nটি লস হলে পুঁজির ${(maxLoss / capital * 100).let { fmt(it) }}% হারাবে।"
        resultBox.addView(text(riskText, 13f, if (maxLoss >= capital) red else Color.DKGRAY, true)
            .apply { setPadding(0, dp(10), 0, 0) })
        renderTracker(capital, payout, stake, n)
    }

    private fun renderTracker(capital: Double, payout: Double, stake: Double, n: Int) {
        trackerBox.removeAllViews()
        var balance = capital
        val rate = payout / 100.0
        for (i in 0 until n) {
            when (outcomes.getOrNull(i)) {
                true -> balance += stake * rate
                false -> balance -= stake
                null -> {}
            }
        }
        trackerBox.addView(text("ট্রেড শেষে আনুমানিক ব্যালেন্স: ${money(balance)}", 16f, ink, true))
        for (i in 0 until n) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            row.addView(text("ট্রেড ${i + 1}", 14f, ink, true), LinearLayout.LayoutParams(0, dp(46), 1f))
            val status = when (outcomes.getOrNull(i)) { true -> "Win"; false -> "Loss"; null -> "Pending" }
            row.addView(text(status, 13f, if (outcomes.getOrNull(i) == false) red else green, true).apply {
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(72), dp(46)))
            val win = Button(this).apply {
                text = "Win"
                textSize = 11f
                setOnClickListener { outcomes[i] = true; calculate() }
            }
            val loss = Button(this).apply {
                text = "Loss"
                textSize = 11f
                setOnClickListener { outcomes[i] = false; calculate() }
            }
            row.addView(win, LinearLayout.LayoutParams(dp(65), dp(44)))
            row.addView(loss, LinearLayout.LayoutParams(dp(65), dp(44)))
            trackerBox.addView(row)
            val divider = View(this).apply { setBackgroundColor(Color.LTGRAY) }
            trackerBox.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
        val reset = Button(this).apply {
            text = "সব ফলাফল রিসেট"
            setOnClickListener {
                outcomes = MutableList(n) { null }
                calculate()
            }
        }
        trackerBox.addView(reset, matchWrap())
    }

    private fun addResult(label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        row.addView(text(label, 13f, Color.DKGRAY, false))
        row.addView(text(value, 17f, ink, true))
        resultBox.addView(row)
        val divider = View(this).apply { setBackgroundColor(Color.rgb(232, 235, 238)) }
        resultBox.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun money(v: Double) = "$" + String.format(Locale.US, "%,.2f", v)
    private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
}
