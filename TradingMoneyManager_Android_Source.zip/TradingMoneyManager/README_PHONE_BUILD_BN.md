# ফোন থেকে APK বানানোর সহজতম পথ (GitHub Actions)

এই প্রজেক্টে `.github/workflows/build-apk.yml` যোগ করা আছে। GitHub-এ সোর্স আপলোড করলে GitHub-এর সার্ভার APK build করে Artifact হিসেবে দেবে।

## ফোনে করণীয়
1. ZIP extract করুন (Files app বা ZIP extractor দিয়ে)।
2. ব্রাউজারে https://github.com খুলে সাইন ইন/অ্যাকাউন্ট তৈরি করুন।
3. `+` → `New repository` চাপুন, নাম দিন `TradingMoneyManager`, Public বা Private বেছে `Create repository` করুন।
4. নতুন repository-তে `Add file` → `Upload files` ব্যবহার করে extracted প্রজেক্টের সব ফাইল/ফোল্ডার আপলোড করুন। `.github/workflows/build-apk.yml` ফাইলটিও অবশ্যই থাকতে হবে। যদি মোবাইল UI-তে hidden `.github` ফোল্ডার আপলোড করা না যায়, repository-তে `Add file` → `Create new file` দিয়ে `.github/workflows/build-apk.yml` নাম দিয়ে workflow ফাইলের কনটেন্ট যোগ করুন।
5. `Commit changes` করুন. GitHub Actions workflow push-এ build-ийг эхлүүлнэ; প্রয়োজনে Actions tab → `Build Trading Money Manager APK` → `Run workflow` চাপুন।
6. Actions-এ সর্বশেষ run খুলুন। সবুজ checkmark হলে নিচে `Artifacts` অংশে `TradingMoneyManager-debug-apk` ডাউনলোড করুন।
7. Artifact ZIP extract করে `app-debug.apk` ফোনে ইনস্টল করুন। Android Settings-এ ওই file manager/browser-এর জন্য “Install unknown apps” অনুমতি লাগতে পারে।

## সতর্কতা
- এটি debug APK, Play Store-এর signed release APK নয়।
- GitHub account প্রয়োজন। Build failure হলে Actions run-এর log দেখে ঠিক করতে হবে।
- Binary options high risk; recovery কখনো নিশ্চিত নয়।
